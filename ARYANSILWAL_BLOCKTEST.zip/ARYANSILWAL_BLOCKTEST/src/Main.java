import MODEL.Item;
import MODEL.Order;
import MODEL.User;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {


        Item i1=new Item("t1","2222","b1",3000);
        Item i2=new Item("t2","2212","b2",4000);
        Item i3=new Item("t3","2213","b1",5000);
        Item i4=new Item("t4","2214","b1",6000);
        Item i5=new Item("t5","2215","b2",7000);


        ArrayList<Item> items_u1=new ArrayList<>();

        items_u1.add(i1);
        items_u1.add(i2);



        ArrayList<Item> items_u2=new ArrayList<>();
        items_u2.add(i3);
        items_u2.add(i4);


        ArrayList<Order> orders_u1=new ArrayList<>();
        Order u1_o1=new Order("u1",items_u1);
        Order u1_o2=new Order("u1",items_u1);

        orders_u1.add(u1_o1);
        orders_u1.add(u1_o2);


        ArrayList<Order> orders_u2=new ArrayList<>();
        Order u2_o1=new Order("u2",items_u2);
        Order u2_o2=new Order("u2",items_u2);

        orders_u1.add(u2_o1);
        orders_u1.add(u2_o2);

     i1.display();

    }
}
